/* STOCK MARKET PROGRAM
 *
 * Designed by: Group 2
 * Group Members: Deon Lundy, Robert Edsall, Chad Glitz, Brent Koryba
 * DATE STARTED: May 1, 2015
 *
 */

#include <iostream>
#include <string>
#include <fstream>
#include <cassert>
using namespace std;

class stockType
{
public:
	string userName; // gets name of User
	string symbol[10]; // stock Symbol
	double oPrice[10]; // Opening Price
	double cPrice[10]; // Closing Price
	double tHigh[10]; // Today's High
	double tLow[10]; // Today's Low
	double pClose[10]; // Previous closing Price (yesterday)
	int volume[10]; // Number of shares Currently being held

	void leader();

	stockType(); // Constructor, initializes all variables
	//~stockType(); // Destructor

private:
	void getData();
	void listChoice();
	void printData();

protected:
	// Protected Members
};

int main()
{
	stockType stock;

	stock.leader();

	return 0;
}

void stockType::leader()
{
	// Because all other functions are private. The 'Leader' Function will
	// be the only Public function and its Job will be to Call all other functions.

	// Gets UserName
	cout << "Please enter your Name" << endl;
	cin >> userName;
	cout << string(25,'\n');

	// Calls Functions
	getData();
	listChoice();
	printData();
}

void stockType::getData()
{
	// Function extracts Data from stock.txt file,
	// Stores data in appropriate variables.
	// (See ch.3 [pg.157] for extracting data from files)

	ifstream inData; // Creates input file stream variable 'inData'.
	inData.open("stock.txt"); // Opens "stock.txt" file

	assert(inData);
	for (int i=0; i < 10; i++) // Here, we will extract values into variables.
	{
		// Code to Extract Data goes Here
		inData >> symbol[i] >> oPrice[i] >> cPrice[i] >> tHigh[i]
			>> tLow[i] >> pClose[i] >> volume[i];

		// Outputting Extracted Data
		cout << string(25, '-') << endl;
		cout << "Company Symbol: " << symbol[i] << endl
			 << "Opening Price: $" << oPrice[i] << endl
			 << "Closing Price: $" << cPrice[i] << endl
			 << "Today's High: $" << tHigh[i] << endl
			 << "Today's Low: $" << tLow[i] << endl
			 << "Previous Closing Price: $" << pClose[i] << endl
			 << "Stock Volume: " << volume[i] << endl;
		cout << string(25, '-') << endl;
	}

	inData.close(); // Closes "stock.txt" file.
}

void stockType::listChoice()
{
	int choice;

	// Function allows user to choose which Listing they would like to produce.
	// SORT BY (Symbol, or percent gain) --- |See ch.8 && ch.16 for Sorting operations|

	cout << "Hello " << userName << ", Which Listing option would you like?";
	cout << endl << endl;
	cout << " 1 = Sort by Stock Symbol." << endl;
	cout << " 2 = Sort by Percent Gain (High to Low)." << endl;
	cin >> choice;

	if (choice == 1) // User choice will dictate which 'Sort' algorithm is executed.
		cout << "Execute Action #1";
	else if (choice == 2)
		cout << "Execute Action #2";
	else
		cout << "Sorry. Your input is invalid. Please try again!" << endl;
		listChoice();
}
void stockType::printData()
{
	// Function prints Extracted Data
	// in appropriate Format.
	// (See ch.3[pg.142] for formatting Output)
}
stockType::stockType()
{
	// Initializes all variables
	symbol[10] = "AAA";
	oPrice[10] = 0.00;
	cPrice[10] = 0.00;
	tHigh[10] = 0.00;
	tLow[10] = 0.00;
	pClose[10] = 0.00;
	volume[10] = 0;
}
