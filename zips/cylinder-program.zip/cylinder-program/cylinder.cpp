#include <iostream>
#include <string>
#define _USE_MATH_DEFINES
#include <cmath>
#include <iomanip>

using namespace std;

// Function Prototypes ////////////////
int goodBye();

class circleType
{
public:
	void setRadius(double r);
	// Function to Set Radius
	double getRadius();
	// Function to return Radius
	double area();
	// Function to return the area of a Circle
	double circumference();
	// Function to return Circumference;
	circleType (double r = 0);
	// Constructor with default parameter
	// Radius is set according to the parameter
	// The default value of the radius is 0.0
	// Postcondition: radius = r;

private:
	double radius;
};

class cylinderType: public circleType
{
public:
	const double CONSTANT = 0.353146667;

	void getName();
	void getData();
	void calculateData();
	void menu();
	void printData();
	void reviewData();
	void moreOptions();
private:
	// User Data Storage
	string userName;
	double radiusBase;
	double height;
	double uPaintCost;
	double uShipCost;
	double paintCost;
	double shipCost;

	//Calculated Data Storage
	double totalSurface;
	//double itemSquareFeet;
	double itemCubicFeet;
	double itemLiters;
	double totalCost;
};

// Formulas /////////////////////////////
/*
 * Total Surface Area = 2(PI x r x h) + 2(PI x r x r)
 * Square Footage == (Length x Height)
 * Cubic Feet == (Square Footage x Height)
 * Item Liters == (Cubic Feet / .353146667)
 * Shipping Cost == (Liters x costPerLiter)
 * Paint Cost == (Square Footage x costPerSquareFoot)
*/

int main()
{

	cylinderType run;

	run.getName();

	return 0;
}

void circleType::setRadius(double r)
{
	if (r >= 0)
		radius = r;
	else
		radius = 0;
}
double circleType::getRadius()
{
	return radius;
}
double circleType::area()
{
	return 3.1416 * radius * radius;
}
double circleType::circumference()
{
	return 2 * 3.1416 * radius;
}
circleType::circleType(double r)

{
	setRadius(r);
}

void cylinderType::getName()
{
	cout << "Please enter your Name" << endl;
	cin >> userName;
	cout << endl;

	getData();
}
void cylinderType::getData()
{
	// Algorithm to gather User Data

	cout << "Please enter the Radius of the Base (in Feet)" << endl;
	cin >> radiusBase;
	cout << endl;

	cout << "Please enter Height (in Feet)" << endl;
	cin >> height;

	cout << "Please enter Paint Cost per Square Foot (Ex: .22 for 25cents | 2.22 for $2.22)" << endl;
	cin >> uPaintCost;

	cout << "Please enter Shipping Cost Per Liter" << endl;
	cin >> uShipCost;

	calculateData();

}

void cylinderType::calculateData()
{
	// Algorithm to calculate Data

	totalSurface = radiusBase * height;
	itemCubicFeet = totalSurface * height;
	itemLiters = itemCubicFeet/CONSTANT;
	paintCost = uPaintCost * totalSurface;
	shipCost = uShipCost * itemLiters;
	totalCost = paintCost + shipCost;

	cout << string(50,'\n');

	menu();
}

void cylinderType::menu()
{
	int choice;

	cout << string(50,'\n');

	cout << userName << ", What would you like to Do?" << endl;
	cout << "------------------------------------" << endl;
	cout << "1 = Review Data Entered." << endl;
	cout << "2 = Edit Data Entered." << endl;
	cout << "3 = Checkout (Cost Summary)" << endl;
	cout << "4 = Exit Program" << endl;
	cout << "------------------------------------" << endl;
	cout << "Choice: ";
	cin >> choice;

	switch (choice)
	{
	case 1:
		reviewData();
		break;
	case 2:
		cout << string(50,'\n');
		getData();
		break;
	case 3:
		cout << string(50,'\n');
		printData();
		moreOptions();
		break;
	default:
		goodBye();
		break;
	}
}

void cylinderType::printData()
{
	// Algorithm to print Data

	cout << fixed << setprecision(2);

	cout << "------------------------------------" << endl;
	cout << "COST SUMMARY: " << endl;
	cout << "------------------------------------" << endl;
	cout << "Paint Cost: $" << paintCost << endl;
	cout << "Ship Cost: $" << shipCost << endl;
	cout << "Total Cost: $" << totalCost << endl;
	cout << "------------------------------------" << endl;

}

void cylinderType::reviewData()
{
	char choice;
	cout << string(50,'\n');

	cout << "------------------------------------" << endl;
	cout << "DATA ENTERED: " << endl;
	cout << "------------------------------------" << endl;
	cout << "Radius: " << radiusBase << endl;
	cout << "Height: " << height << endl;
	cout << "Paint Cost/SqFt: $" << uPaintCost << endl;
	cout << "Ship Cost/Liter: $" << uShipCost << endl;
	cout << "------------------------------------" << endl;

	cout << "CALCULATED DATA: " << endl;
	cout << "------------------------------------" << endl;
	cout << "Total Surface Area: " << totalSurface << endl;
	cout << "Item's Cubic Feet: " << itemCubicFeet << endl;
	cout << "Item's Liter Capacity: " << itemLiters << endl;
	cout << "------------------------------------" << endl;

	cout << "Would you like to Edit these values? Y/N" << endl;
	cin >> choice;

	if (choice == 'Y' || choice == 'y')
		{
		cout << string(50,'\n');
		getData();
		}
	else
	{
		cout << string(50,'\n');
		menu();
	}

}

void cylinderType::moreOptions()
{
	char choice;

	cout << userName << ", Would you like to see more Options? Y/N" << endl;
	cin >> choice;

	if (choice == 'Y' || choice == 'y')
			{
			cout << string(50,'\n');
			menu();
			}
		else
		{
			goodBye();
		}

}

int goodBye()
{
	cout << string(50,'\n');
	cout << "Goodbye" << endl << endl;
	return 0;
}
