#include <iostream>
#include <string>
#include <iomanip>
#include <cctype>
#include <windows.h>

using namespace std;

// OBJECTS //////////////////////////
class romanType
{	
	public:
		void getUserInput();
		
	private:
		string romanNum;
		
		void convertInput(string romanNum, double& romanDec);
		int printRoman(string romanNum, double romanDec);
};

int main()
{
	
	romanType director;
	
	director.getUserInput();
	
	return 0;
}

void romanType::getUserInput()
{
	double romanDec;
	romanDec = 0;
	
	cout << "This program will convert a Roman Numeral into a Decimal";
	cout << endl << endl;
	
	for (int i= 0; i<5; i++)
		{
			cout << ".";
			Sleep(300);
		}
	cout << endl << endl;
	cout << "Pleaes enter a Roman Numeral" << endl;
	cin >> romanNum;
	cout << endl << endl;
	
	convertInput(romanNum, romanDec);
	printRoman(romanNum, romanDec );
}

void romanType::convertInput(string romanNum, double& romanDec)
{	
	romanDec = 0;
	cout << fixed << setprecision(2);
	cout << "Converting Input" << endl << endl;
	
		for (int i= 0; i<5; i++)
		{
			cout << ".";
			Sleep(300);
		}
	cout << endl << endl;
	
		for (int i=0; i < romanNum.length(); i++)
		{
			if (romanNum[i] == 'M' || romanNum[i] == 'm')
			{
				romanDec = romanDec + 1000;
			}
			else if (romanNum[i] == 'D' || romanNum[i] == 'd')
			{
				romanDec = romanDec + 500;
			}
			else if (romanNum[i] == 'C' || romanNum[i] == 'c')
			{
				romanDec = romanDec + 100;
			}
			else if (romanNum[i] == 'L' || romanNum[i] == 'l')
			{
				romanDec = romanDec + 50;
			}
			else if (romanNum[i] == 'X' || romanNum[i] == 'x')
			{
				romanDec = romanDec + 10;
			}
			else if (romanNum[i] == 'V' || romanNum[i] == 'v')
			{
				romanDec = romanDec + 5;
			}
			else if (romanNum[i] == 'I' || romanNum[i] == 'i')
			{
				romanDec = romanDec + 1;
			}
			else
				cout << "" << endl;
		}
}

int romanType::printRoman(string romanNum, double romanDec)
{
	int choice;
	
	cout << "What Format would you like to Print your Number in?";
	
	cout << endl << endl;
	
	cout << "NOTE: Please enter Numerical Value ONLY";
	cout << endl << endl;
		 
	cout << "     1 = Roman Numeral" << endl << "     2 = Decimal" << endl;
	cout << endl << endl;
	
	cout << "Your Selection: ";
	cin >> choice;
	
		for (int i= 0; i<5; i++)
		{
			cout << ".";
			Sleep(300);
		}
		cout << endl << endl;
	
	if (choice >= 4000 || choice < 0)
		{
			cout << endl << endl;
		cout << "Sorry, invalid input.";
		cout << endl << endl;
		}
	else 
	{
		if (choice == 1)
		{
		cout << "The Roman Numeral is: " << romanNum;
		cout << endl << endl;
		
		for (int i= 0; i<15; i++)
		{
		cout << ".";
		Sleep(300);
		}
		cout << endl << endl;
		
		cout << endl << endl << endl;
		cout << "restarting program in 15secs..." << endl << endl;
		for (int i= 0; i<15; i++)
		{
		cout << ".";
		Sleep(300);
		}
		cout << string(50, '\n');
		cout << endl << endl;

		getUserInput();
		}
		
		else if (choice == 2)
			{
			cout << "The Decimal value is: " << romanDec;
			cout << endl << endl;
			
			for (int i= 0; i<15; i++)
			{
			cout << ".";
			Sleep(300);
			}
			cout << endl << endl;
			
			cout << endl << endl << endl;
			cout << "restarting program in 15secs..." << endl << endl;
			for (int i= 0; i<15; i++)
			{
				cout << ".";
				Sleep(300);
			}
			cout << string(50, '\n');
			cout << endl << endl;
	
			getUserInput();
			}
		else
			{
			cout << "Sorry, Invalid Request.";
			cout << endl << endl;
			}
	}
		
		return 0;
}
