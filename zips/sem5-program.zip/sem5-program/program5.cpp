#include <iostream>
#include <string>

using namespace std;

// Function Prototypes
void getData();

int main()
{

	getData();

	return 0;
}

void getData()
{
	string userName;
	double feet, inches, lengthInCentimeters;

	// Conversion
	/*
	 * 1 foot == 30.48 cm
	 * 1 inch == 2.54 cm
	 *
	 *feet = feet * 30.48
	 *inch = inch * 2.54
	 *inch lengthInCentimeters = ((feet * 30.48)+ (inch * 2.54))
	 *  */

	cout << "Please Enter Your name" << endl;
	cin >> userName;

	try
	{
		cout << string(50,'\n');
		cout << userName << ", You will now be prompted to enter a Length (in feet and inches).";
		cout << endl << endl;
		cout << "----------------------------------------------" << endl;
		cout << "Please Enter Feet: ";
		cin >> feet;

		if (feet < 0)
			throw string("Negative Number");

		cout << "(feet x 30.48 = feet in Centimeters)" << endl;
		cout << "----------------------------------------------" << endl;

		cout << "Please Enter Inches: ";
		cin >> inches;
		if (inches < 0)
			throw string("Negative Number");
		else if (!cin)
			throw string("Sorry. inappropriate value entered. System in Fail State");
		cout << "(inches x 2.54 = inches in Centimeters)" << endl;
		cout << "---------------------------------------------- " << endl;

		lengthInCentimeters = ((feet * 30.48)+ (inches * 2.54));

		cout << endl << endl;
		cout << "Length: " << lengthInCentimeters << " Centimeters";
	}
	catch (string x)
	{
		cout << string(50,'\n');
		cout << x << endl;
	}
}
